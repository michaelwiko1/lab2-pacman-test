# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/framebox{parbox{12cm}{ThisprogramisdevelopedaspartofanassignmentatXXXXXXXBasedontedhereareexclusivepropertyoftheauthorunderthelawsofCITYANDCOUNTRY.}};LFS=12;AAT/;
$cached_env_img{$key} = q|4#4|; 

$key = q/>;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|2#2|; 

$key = q/<;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|1#1|; 

$key = q/framebox{parbox{12cm}{Laboratory2--aprogramformodelingobjectsinPackMan.Copyright,Boston,MA02110-1301USAparThisfoldercontainstheimplementationofXXXX}};LFS=12;AAT/;
$cached_env_img{$key} = q|3#3|; 

1;


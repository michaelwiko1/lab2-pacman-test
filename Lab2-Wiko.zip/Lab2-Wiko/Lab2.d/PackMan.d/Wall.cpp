#include <iostream>

#include "BoardObjectH.h"
#include "WallH.h"

void Wall :: touch ()
		{
		   set_color(color1);
		}
